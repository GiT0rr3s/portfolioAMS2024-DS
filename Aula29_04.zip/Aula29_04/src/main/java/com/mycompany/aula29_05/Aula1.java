/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula29_05;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Aula1 {
    public static int CalcularDobro(int numero){
        return numero * 2;
    }

    public static void main(String[] args) {
        int numero = 5;
        var resultado = CalcularDobro(numero);
        System.out.println("O dobro de " + numero + " é: " +resultado);
    }
}

